# ExoPlayer-Demo

This git repo contains implementation around how to set up exoplayer & many of its features 
For Implementation, I have put up a list of articles which refer to different branches of this repo only do give them a read

## Medium Articles
- [Let's Dive into Exo-Player (Part I)](https://medium.com/@prateekbatra54/lets-dive-into-exo-player-working-5b6aa7042421)
- [Let's Dive into Exo-Player (Part II): Adding Quality Control](https://medium.com/@prateekbatra54/lets-dive-into-exo-player-part-ii-adding-quality-control-a0c0b50cc628)
- [Let's Dive into Exo-Player (Part III): The DRM Way](https://medium.com/proandroiddev/exo-player-the-drm-way-part-iii-13701b20e903)
- [Let's Dive into Exo-Player (Part IV): Caching Video](https://proandroiddev.com/lets-dive-into-exo-player-part-iv-caching-video-7ac2dc430dbf)
- [Let's Dive into Exo-Player (Part V): How Offline Downloads Works](https://medium.com/@prateekbatra54/exo-player-how-offline-downloads-works-part-v-be54f5f9af4b)

## Contributing

Pull requests are welcome. For any major/minor changes, please open an issue first
to discuss what you would like to change.

## Connect with me

[Twitter](https://twitter.com/its_pra_tick)

Media streaming with ExoPlayer
===
The code in this repository accompanies the [Media streaming with ExoPlayer codelab](https://codelabs.developers.google.com/codelabs/exoplayer-intro). If you are looking to get started with [ExoPlayer](https://developer.android.com/guide/topics/media/exoplayer), the codelab is a great place to start.  